/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"

void Truck_Stop() 
{
    Forward_out_Write(0);
    Reverse_out_Write(0);
    Left_out_Write(0);
    Right_out_Write(0);
}

void Truck_Forward(uint32 milliseconds) 
{
    Reverse_out_Write(0);
    Forward_out_Write(1);
    CyDelay(milliseconds);
}

void Truck_Reverse(uint32 milliseconds) 
{
    Forward_out_Write(0);
    Reverse_out_Write(1);
    CyDelay(milliseconds);
}

void Truck_Right() 
{
    Left_out_Write(0);
    Right_out_Write(1);
}

void Truck_Left() 
{
    Right_out_Write(0);
    Left_out_Write(1);
}

void Truck_Straight() 
{
    Right_out_Write(0);
    Left_out_Write(0);
}


int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    PWM_1_Stop();
    Truck_Stop();
    CyDelay(3000);
    int i = 0;

//    for(;;)
    for(i=0; i<4; ++i)
    {
        /* Place your application code here. */
        Truck_Forward(500);
        Truck_Right();
        Truck_Forward(500);
        Truck_Straight();
        Truck_Stop();

    }
}

/* [] END OF FILE */
